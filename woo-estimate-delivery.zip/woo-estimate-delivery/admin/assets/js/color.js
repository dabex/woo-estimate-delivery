(function($) {
"use strict";
$('.textedd-color').wpColorPicker();
$('.deledd-color').wpColorPicker();
})(jQuery);